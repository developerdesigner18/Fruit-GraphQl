
export interface FruitEvent {
    readonly eventType: string;
    readonly payload: any;
  }
  