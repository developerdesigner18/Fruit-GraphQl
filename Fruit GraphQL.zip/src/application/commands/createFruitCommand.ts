export interface CreateFruitCommand {
    name: string;
    description: string;
    limit: number;
  }
  