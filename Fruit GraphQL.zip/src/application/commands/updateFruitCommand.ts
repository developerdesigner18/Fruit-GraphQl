export interface UpdateFruitCommand {
    name: string;
    description: string;
  }
  