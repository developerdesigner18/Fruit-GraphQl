export interface DeleteFruitCommand {
    name: string;
    forceDelete: boolean;
  }
  