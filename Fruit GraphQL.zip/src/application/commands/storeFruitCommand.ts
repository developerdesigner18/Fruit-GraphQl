export interface StoreFruitCommand {
    name: string;
    amount: number;
  }
  