export interface RemoveFruitCommand {
    name: string;
    amount: number;
  }
  